import tkinter as tk
import webbrowser

class SkyhawkBrowser:
    def __init__(self, root):
        self.root = root
        self.package_name = "com.garudaxyber.skyhawk"
        self.root.title(f"Skyhawk Browser | {self.package_name}")
        self.root.geometry("500x250")
        self.root.configure(bg="#121212") # Tema gelap khas Cyber

        # Header
        self.label = tk.Label(root, text="🦅 SKYHAWK BROWSER", font=("Arial", 16, "bold"), fg="#00ffcc", bg="#121212")
        self.label.pack(pady=15)

        # Input URL
        self.url_label = tk.Label(root, text="Masukkan URL atau Kata Kunci:", fg="white", bg="#121212")
        self.url_label.pack()
        
        self.url_entry = tk.Entry(root, width=50, font=("Arial", 10))
        self.url_entry.insert(0, "https://google.com")
        self.url_entry.pack(pady=5)

        # Tombol Jelajah
        self.btn_launch = tk.Button(root, text="JELAJAHI AMAN", command=self.launch_browser, bg="#00ffcc", fg="black", font=("Arial", 10, "bold"))
        self.btn_launch.pack(pady=15)

    def launch_browser(self):
        url = self.url_entry.get()
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "https://www.google.com/search?q=" + url
        
        # Membuka dengan mode aman bawaan sistem
        webbrowser.open(url)

if __name__ == "__main__":
    root = tk.Tk()
    app = SkyhawkBrowser(root)
    root.mainloop()