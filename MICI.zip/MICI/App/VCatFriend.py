import tkinter as tk
from tkinter import messagebox

class FriendCat:
    def __init__(self, root):
        self.root = root
        self.package_name = "com.garudaxyber.friendcatV"
        self.root.title("Friend Cat - " + self.package_name)
        self.root.geometry("400x350")
        
        self.status_label = tk.Label(root, text="Status: Kucing sedang menunggu perintah! 🐱", font=("Arial", 12))
        self.status_label.pack(pady=20)
        
        self.bed_label = tk.Label(root, text="", font=("Arial", 30))
        self.bed_label.pack(pady=10)
        
        self.btn_feed = tk.Button(root, text="Beri Makan", command=self.feed_cat, width=20)
        self.btn_feed.pack(pady=5)
        
        self.btn_rest = tk.Button(root, text="Istirahatkan / Tidur (1 Jam)", command=self.rest_cat, width=20)
        self.btn_rest.pack(pady=5)
        
        self.btn_exit = tk.Button(root, text="Tutup", command=root.destroy, width=20)
        self.btn_exit.pack(pady=20)

    def feed_cat(self):
        self.status_label.config(text="Status: Kucing sedang makan... Nyamm! 🐟")
        self.bed_label.config(text="")
        messagebox.showinfo("Friend Cat", "Meow! Terima kasih makanannya!")
        self.status_label.config(text="Status: Kucing kenyang dan senang! 🐱")

    def rest_cat(self):
        # 1 jam = 3600000 milidetik
        self.status_label.config(text="Status: Kucing tidur selama 1 jam... Zzz... 💤")
        self.bed_label.config(text="🛏️")
        self.root.after(3600000, self.wake_up)

    def wake_up(self):
        self.status_label.config(text="Status: Kucing sudah bangun setelah 1 jam! 🐱")
        self.bed_label.config(text="")

if __name__ == "__main__":
    root = tk.Tk()
    app = FriendCat(root)
    root.mainloop()