import tkinter as tk
import random

class DesktopVCatFriend:
    def __init__(self, root):
        self.root = root
        self.package_name = "com.garudaxyber.friendcatV"
        self.root.bind("<Escape>", lambda e: self.root.destroy())

        # 1. KONFIGURASI WINDOW TRANSPARAN & OVERLAY DESKTOP
        self.root.overrideredirect(True) # Menghilangkan bingkai Windows (Close, Maximize, dll)
        self.root.attributes("-topmost", True) # Memaksa kucing selalu berada di atas semua aplikasi
        self.root.config(bg='black')
        self.root.wm_attributes("-transparentcolor", "black") # Membuat latar belakang hitam jadi tembus pandang (transparan)
        
        # 2. ANIMASI DAN KOORDINAT JALAN KUCING
        self.frames = ["🐱", "🐈", "🐾"] # Variasi tampilan biar seolah bergerak
        self.current_frame = 0
        
        # Posisi awal di layar desktop
        self.x = 200
        self.y = 500 # Kucing akan muncul di bagian bawah desktop
        self.direction = 1 # 1 = Jalan ke Kanan, -1 = Jalan ke Kiri
        self.speed = 3 # Kecepatan melangkah kucing
        
        # Set ukuran jendela pas dengan ukuran emoji kucing
        self.root.geometry(f"100x100+{self.x}+{self.y}")
        
        # 3. LABEL UTAMA KUCING (Menggunakan Emoji Besar)
        self.cat_label = tk.Label(root, text="🐱", font=("Segoe UI Emoji", 48), bg="black", fg="white")
        self.cat_label.pack()
        
        # 4. KONTROL MOUSE (Bisa Diklik Kanan Untuk Menu / Keluar)
        self.cat_label.bind("<Button-3>", self.show_context_menu) # Klik Kanan untuk Menu Rahasia
        
        # Buat Menu Klik Kanan
        self.menu = tk.Menu(self.root, tearoff=0, bg="#0d1117", fg="#00ff66", font=("Courier New", 10))
        self.menu.add_command(label="[ GarudaXyber VCatFriend ]", state="disabled")
        self.menu.add_separator()
        self.menu.add_command(label="Beri Makan 🐟", command=self.feed_cat)
        self.menu.add_command(label="Tidur 💤", command=self.rest_cat)
        self.menu.add_command(label="Wipe / Tutup App 🗑️", command=self.root.destroy)

        # 5. AKTIFKAN ENGINE UTAMA (JALAN OTOMATIS)
        self.is_sleeping = False
        self.update_behavior()

    def update_behavior(self):
        if not self.is_sleeping:
            # Mengacak gerakan agar kucing bertingkah natural
            if random.randint(1, 100) > 97:
                self.direction *= -1 # Kucing tiba-tiba putar balik arah!
            
            # Update Posisi Koordinat Desktop Jenderal
            self.x += self.direction * self.speed
            
            # Batas layar kiri dan kanan agar kucing gak kabur keluar monitor (Asumsi lebar layar 1366)
            screen_width = self.root.winfo_screenwidth()
            if self.x < 0 or self.x > (screen_width - 100):
                self.direction *= -1
            
            # Ganti Frame Animasi Langkah Kucing
            self.current_frame = (self.current_frame + 1) % len(self.frames)
            self.cat_label.config(text=self.frames[self.current_frame])
            
            # Geser jendela aplikasi secara real-time di desktop
            self.root.geometry(f"100x100+{self.x}+{self.y}")
            
        # Mengulang fungsi jalan setiap 150 milidetik (Stabil & RAM Ringan)
        self.root.after(150, self.update_behavior)

    def feed_cat(self):
        self.is_sleeping = False
        self.cat_label.config(text="🐟")
        self.root.after(1500, lambda: self.cat_label.config(text="🐱")) # Makan selama 1.5 detik lalu normal lagi

    def rest_cat(self):
        self.is_sleeping = True
        self.cat_label.config(text="💤")
        # Kucing akan otomatis bangun dan jalan lagi setelah 10 detik (Biar Jenderal gak kelamaan nunggu 1 jam pas testing!)
        self.root.after(10000, self.wake_up)

    def wake_up(self):
        if self.is_sleeping:
            self.is_sleeping = False
            self.cat_label.config(text="🐱")

    def show_context_menu(self, event):
        self.menu.post(event.x_root, event.y_root)

if __name__ == "__main__":
    root = tk.Tk()
    app = DesktopVCatFriend(root)
    root.mainloop()