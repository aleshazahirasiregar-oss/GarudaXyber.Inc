import tkinter as tk
from tkinter import messagebox
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class AirMailApp:
    def __init__(self, root):
        self.root = root
        self.package_name = "com.garudaxyber.airmail"
        self.root.title(f"AirMail | {self.package_name}")
        self.root.geometry("500x550")
        self.root.configure(bg="#1a1a1a") # Tema Gelap

        # Header
        self.label = tk.Label(root, text="📩 GARUDA AIRMAIL", font=("Arial", 16, "bold"), fg="#00e676", bg="#1a1a1a")
        self.label.pack(pady=15)

        # Form Pengirim
        self.create_label("Email Pengirim (Gmail):")
        self.sender_entry = tk.Entry(root, width=50, bg="#333", fg="white", insertbackground="white")
        self.sender_entry.pack(pady=5)

        self.create_label("App Password (Kunci Akses):")
        self.pwd_entry = tk.Entry(root, width=50, show="*", bg="#333", fg="white", insertbackground="white")
        self.pwd_entry.pack(pady=5)

        # Form Penerima
        self.create_label("Email Penerima:")
        self.receiver_entry = tk.Entry(root, width=50, bg="#333", fg="white", insertbackground="white")
        self.receiver_entry.pack(pady=5)

        # Subjek
        self.create_label("Subjek Pesan:")
        self.sub_entry = tk.Entry(root, width=50, bg="#333", fg="white", insertbackground="white")
        self.sub_entry.pack(pady=5)

        # Isi Pesan
        self.create_label("Isi Pesan / Log Sistem:")
        self.msg_text = tk.Text(root, height=8, width=50, bg="#333", fg="white", insertbackground="white")
        self.msg_text.pack(pady=5)

        # Tombol Kirim
        self.btn_send = tk.Button(root, text="KIRIM AIRMAIL", command=self.send_email, bg="#00e676", fg="black", font=("Arial", 10, "bold"))
        self.btn_send.pack(pady=20)

    def create_label(self, text):
        lbl = tk.Label(self.root, text=text, fg="white", bg="#1a1a1a", anchor="w")
        lbl.pack(fill=tk.X, padx=50)

    def send_email(self):
        sender = self.sender_entry.get()
        password = self.pwd_entry.get()
        receiver = self.receiver_entry.get()
        subject = self.sub_entry.get()
        body = self.msg_text.get("1.0", tk.END)

        if not sender or not password or not receiver:
            messagebox.showerror("Error", "Kolom Pengirim, Password, dan Penerima wajib diisi!")
            return

        try:
            # Mengatur Format Pesan
            msg = MIMEMultipart()
            msg['From'] = sender
            msg['To'] = receiver
            msg['Subject'] = f"[Garuda AirMail] {subject}"
            msg.attach(MIMEText(body, 'plain'))

            # Koneksi ke Server SMTP Gmail (Secure TLS)
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            server.login(sender, password)
            server.sendmail(sender, receiver, msg.as_string())
            server.quit()

            messagebox.showinfo("Sukses", "AirMail berhasil dikirim dengan aman! 🦅")
        except Exception as e:
            messagebox.showerror("Gagal", f"Gagal mengirim pesan.\nError: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = AirMailApp(root)
    root.mainloop()u6