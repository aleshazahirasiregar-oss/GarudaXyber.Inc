import psutil
import tkinter as tk
from tkinter import messagebox

class SentinelApp:
    def __init__(self, root):
        self.root = root
        self.package_name = "com.garudaxyber.sentinel"
        self.root.title(f"Sentinel | {self.package_name}")
        self.root.geometry("450x400")
        
        # Header
        self.label = tk.Label(root, text="Sentinel System Guard 🛡️", font=("Arial", 16, "bold"), fg="darkblue")
        self.label.pack(pady=10)
        
        # Area Monitor
        self.status_box = tk.Text(root, height=15, width=50, font=("Consolas", 9))
        self.status_box.pack(pady=10)
        
        # Kontrol
        self.btn_check = tk.Button(root, text="SCAN PROSES BERJALAN", command=self.scan_processes, bg="gray", fg="white")
        self.btn_check.pack(fill=tk.X, padx=20, pady=5)
        
        self.btn_exit = tk.Button(root, text="TUTUP SENTINEL", command=root.destroy, bg="red", fg="white")
        self.btn_exit.pack(fill=tk.X, padx=20, pady=5)

    def scan_processes(self):
        self.status_box.delete(1.0, tk.END)
        self.status_box.insert(tk.END, f"--- {self.package_name} ---\n")
        self.status_box.insert(tk.END, "Memindai integritas sistem...\n\n")
        
        count = 0
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                pinfo = proc.info
                self.status_box.insert(tk.END, f"PID: {pinfo['pid']} | {pinfo['name']}\n")
                count += 1
                if count > 50: break # Membatasi tampilan agar tidak lag
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        
        self.status_box.insert(tk.END, "\n--- Pemindaian Selesai. Sistem Terproteksi. ---")

if __name__ == "__main__":
    root = tk.Tk()
    app = SentinelApp(root)
    root.mainloop()