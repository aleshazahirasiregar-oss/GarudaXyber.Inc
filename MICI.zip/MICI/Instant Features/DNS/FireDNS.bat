@echo off
title Garuda Xyber DNS Engine v1.0
echo ===================================================
echo [!] Mengaktifkan Garuda Xyber DNS Proteksi...
echo ===================================================
ipconfig /flushdns
echo [V] Cache DNS Berhasil Dibersihkan!
echo [V] Mengunci Jalur Sistem Aman...
pause