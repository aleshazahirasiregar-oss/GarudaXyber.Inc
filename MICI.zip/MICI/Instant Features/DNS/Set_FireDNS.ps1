# ===================================================
# Garuda Xyber DNS Engine v1.0 - Network Configurator
# ===================================================
echo "[!] Mengonfigurasi Jalur DNS Garuda Xyber..."

# Mengambil nama interface jaringan yang sedang aktif (Wi-Fi/Ethernet)
$NetworkAdapter = Get-NetAdapter | Where-Object {$_.Status -eq "Up"}

if ($NetworkAdapter) {
    # Mengatur DNS Utama dan Cadangan secara aman melalui perintah resmi Windows
    Set-DnsClientServerAddress -InterfaceIndex $NetworkAdapter.InterfaceIndex -ServerAddresses ("1.1.1.1","8.8.8.8")
    echo "[V] Jaringan aman berhasil dikunci ke Garuda Xyber DNS Engine!"
} else {
    echo "[X] Koneksi internet tidak ditemukan. Silahkan aktifkan Wi-Fi/LAN Anda."
}
pause