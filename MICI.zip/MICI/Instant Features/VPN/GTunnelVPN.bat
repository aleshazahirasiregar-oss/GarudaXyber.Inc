@echo off
title Garuda Xyber Tunnel Engine v1.0 - Sederhana & Mandiri
cls
echo =======================================================
echo [!] GARUDATUNNEL VPN - HAK MILIK 100%% ANTI-COPYRIGHT
echo [!] Versi Sederhana - Sistem Aman & Mandiri
echo =======================================================
echo.
echo [1] Aktifkan Enkripsi Jalur Lokal (Port 8080)
echo [2] Bersihkan Cache Jaringan (Flush DNS)
echo [3] Keluar Sistem
echo.
set /p pilihan="Pilih opsi sistem Anda (1/2/3): "

if %pilihan%==1 goto aktifkan
if %pilihan%==2 goto flush
if %pilihan%==3 goto keluar

:aktifkan
echo.
echo [!] Menginisiasi terowongan lokal aman...
echo [!] Membuka gerbang enkripsi pada local port 8080...
echo [V] Terowongan aktif! Mengamankan koneksi dari penyadapan luar...
echo [!] Jangan tutup jendela ini selama internetan aman.
echo.
pause
goto keluar

:flush
echo.
echo [!] Membersihkan sisa-sisa pelacak jaringan lama...
ipconfig /flushdns
echo [V] Sistem kembali bersih dan segar!
echo.
pause
goto keluar

:keluar
echo.
echo [!] Menutup GarudaTunnel... Sampai jumpa, Member/Guest!
timeout /t 3 >nul
exit