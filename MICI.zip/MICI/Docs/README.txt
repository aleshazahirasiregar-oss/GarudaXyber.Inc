MICI - Garuda Xyber Suite
Selamat datang di MICI, rangkaian aplikasi eksklusif yang dikembangkan oleh Garuda Xyber. Koleksi ini dirancang untuk pemantauan sistem dan pendamping digital yang aman serta terintegrasi.

📁 Isi Paket
Paket ini berisi:

Friend Cat (com.garudaxyber.friendcatV): Pendamping desktop interaktif untuk kenyamanan sistem.

Sentinel (com.garudaxyber.sentinel): Sistem pengawas integritas proses untuk memantau keamanan sistem dari ancaman.

🚀 Instalasi
Pastikan Python 3.x sudah terinstal di sistem kamu.

Instal pustaka pendukung dengan menjalankan perintah di terminal:


pip install psutil

Ekstrak file MICI.zip ke direktori pilihan kamu.

Jalankan aplikasi melalui perintah:


python nama_file.py

🛡️ Kebijakan Keamanan
Aplikasi dalam paket ini dikembangkan untuk penggunaan internal Garuda Xyber.

Sentinel berfungsi memantau aktivitas proses (PID).

Harap pastikan izin eksekusi diberikan dengan benar agar aplikasi dapat berjalan optimal di lingkungan sistem yang terproteksi (seperti Windows 11-Windows Lainnya).

Jangan membagikan kunci akses folder sistem tanpa izin dari Author.

⚖️ Lisensi
Proyek ini dilindungi oleh MIT License. Lihat file LICENSE.txt untuk informasi lebih lanjut.

Dikembangkan dengan penuh ketelitian oleh Garuda Xyber. Keamanan adalah prioritas utama.